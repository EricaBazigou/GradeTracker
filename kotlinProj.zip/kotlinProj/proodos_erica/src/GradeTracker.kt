class GradeTracker {

    private val students = mutableListOf<Student>()

    fun addStudent(student: Student) {
        students.add(student)
    }

    fun removeStudent(id: Int): Boolean {
        val removed = students.removeIf { it.id == id }

        if (!removed) {
            println("Δεν βρέθηκε φοιτητής με id $id")
        }

        return removed
    }

    fun getAllStudents(): List<Student> {
        return students.toList()
    }

    fun calculateAverage(): Double {
        if (students.isEmpty()) {
            println("Δεν υπάρχουν φοιτητές")
            return 0.0
        }

        return students.map { it.grade }.average()
    }

    fun getHighestGrade(): Student? {
        return students.maxByOrNull { it.grade }
    }

    fun getFailingStudents(): List<Student> {
        return students.filter { it.grade < 5 }
    }

    fun getExcellentStudents(): List<Student> {
        return students.filter { it.grade >= 8.5 }
    }
}