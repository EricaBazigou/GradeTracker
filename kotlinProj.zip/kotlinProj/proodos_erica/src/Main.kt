fun main() {

    val tracker = GradeTracker()

    // Προσθήκη φοιτητών
    tracker.addStudent(Student(1, "Αχιλλέας", 4.5))
    tracker.addStudent(Student(2, "Ανατολή", 9.2))
    tracker.addStudent(Student(3, "Ηλέκτρα", 3.7))
    tracker.addStudent(Student(4, "Αλέξανδρος", 9.8))
    tracker.addStudent(Student(5, "Πάτροκλος", 7.9))
    tracker.addStudent(Student(6, "Ανδρομάχη", 5.5))

    println("Όλοι οι φοιτητές:")
    tracker.getAllStudents().forEach {
        println("${it.id} - ${it.name} : ${it.grade}")
    }

    println("Μέσος όρος: %.1f".format(tracker.calculateAverage()))

    println("\nΑποτυχόντες:")
    tracker.getFailingStudents().forEach {
        println("${it.name} (${it.grade})")
    }

    println("\nΆριστοι:")
    tracker.getExcellentStudents().forEach {
        println("${it.name} (${it.grade})")
    }

    println("\nΔιαγραφή φοιτητή με id 3")
    tracker.removeStudent(3)

    println("\nΝέα λίστα:")
    tracker.getAllStudents().forEach {
        println("${it.id} - ${it.name} : ${it.grade}")
    }

    val best = tracker.getHighestGrade()
    println("\n Καλύτερος φοιτητής:")

    if (best != null) {
        println("${best.name} με βαθμό ${best.grade}")
    }
}